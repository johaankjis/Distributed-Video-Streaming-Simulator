# Distributed Video Streaming Simulator

A cloud-native distributed video streaming simulator that models real-time video delivery across multiple nodes using gRPC, enabling scalability testing, load balancing, and observability under high concurrency conditions.

## Architecture

- **gRPC Video Servers**: 5 replicas streaming video chunks with adaptive bitrate
- **Load Simulator**: Python client simulating 50K+ concurrent connections
- **Kubernetes**: Orchestration with automatic load balancing and fault tolerance
- **Prometheus**: Real-time metrics collection from all nodes
- **Grafana**: Visualization dashboards for system monitoring

## Quick Start

### Prerequisites

- Docker
- Kubernetes (minikube, kind, or cloud provider)
- kubectl configured

### Build and Deploy

\`\`\`bash
chmod +x scripts/build-and-deploy.sh
./scripts/build-and-deploy.sh
\`\`\`

### Access Monitoring

- **Prometheus**: http://localhost:30090
- **Grafana**: http://localhost:30030 (username: admin, password: admin)

### Configure Grafana

1. Add Prometheus data source: http://prometheus-service:9090
2. Import dashboard from `grafana/dashboard.json`

## Key Metrics

- `stream_latency_p99`: 99th percentile streaming latency
- `active_connections`: Current active streaming sessions
- `chunk_error_rate`: Rate of failed chunk deliveries
- `video_chunks_sent_total`: Total chunks delivered
- `client_streams_total`: Total streams initiated by clients

## Testing Fault Tolerance

\`\`\`bash
# Delete a random server pod
kubectl delete pod -l app=video-server --field-selector=status.phase=Running --force --grace-period=0

# Watch Kubernetes reschedule and traffic rebalance
kubectl get pods -l app=video-server -w
\`\`\`

## Scaling

\`\`\`bash
# Scale servers
kubectl scale deployment video-server --replicas=10

# Scale client load
kubectl set env deployment/video-client NUM_CLIENTS=500
\`\`\`

## Architecture Diagram

\`\`\`
┌─────────────┐
│   Clients   │ (50K+ concurrent)
│ Simulator   │
└──────┬──────┘
       │
       ▼
┌─────────────────────────────────┐
│   Kubernetes Service            │
│   (Round-robin Load Balancer)   │
└─────────────────────────────────┘
       │
       ├──────┬──────┬──────┬──────┐
       ▼      ▼      ▼      ▼      ▼
    ┌────┐ ┌────┐ ┌────┐ ┌────┐ ┌────┐
    │Pod1│ │Pod2│ │Pod3│ │Pod4│ │Pod5│
    │gRPC│ │gRPC│ │gRPC│ │gRPC│ │gRPC│
    └─┬──┘ └─┬──┘ └─┬──┘ └─┬──┘ └─┬──┘
      │      │      │      │      │
      └──────┴──────┴──────┴──────┘
                   │
                   ▼
            ┌─────────────┐
            │ Prometheus  │
            │  (Metrics)  │
            └──────┬──────┘
                   │
                   ▼
            ┌─────────────┐
            │   Grafana   │
            │(Dashboards) │
            └─────────────┘
\`\`\`

## Performance Targets

- **Latency**: P99 < 150ms per chunk
- **Throughput**: 10K+ chunks/second system-wide
- **Concurrency**: 50K+ simultaneous streams
- **Availability**: 99.9% uptime with automatic failover
